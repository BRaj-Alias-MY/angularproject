import { NgModule, Component } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { LoginComponent } from "./login/login.component";
import { RegisterComponent } from "./register/register.component";
import { AuthGuard } from "./auth.guard";
import { ServicesComponent } from "./services/services.component";
import { ListserviceComponent } from "./listservice/listservice.component";
import { HomeComponent } from "./home/home.component";

import { MembersComponent } from "./members/members.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: "/login",
    pathMatch: "full"
  },

  {
    path: "services",
    component: ServicesComponent,
    canActivate: [AuthGuard]
  },

  {
    path: "login",
    component: LoginComponent
  },
  {
    path: "register",
    component: RegisterComponent
  },
  {
    path: "listservice",
    component: ListserviceComponent
  },
  {
    path: "home",
    component: HomeComponent
  },
  {
    path: "members",
    component: MembersComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
