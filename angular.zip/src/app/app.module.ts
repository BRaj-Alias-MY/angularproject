import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { RegisterComponent } from "./register/register.component";
import { LoginComponent } from "./login/login.component";

import { FormsModule } from "@angular/forms";
import { AuthService } from "./auth.service";

import { AuthGuard } from "./auth.guard";
import { TokenInterceptorService } from "./token-interceptor.service";
import { Token } from "../../node_modules/@angular/compiler";
import { ServicesComponent } from "./services/services.component";
import { DataTablesModule } from "angular-datatables";
import { NgxPaginationModule } from "ngx-pagination";
import { ListserviceComponent } from "./listservice/listservice.component";
import { HomeComponent } from "./home/home.component";
import { MembersComponent } from "./members/members.component";
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,

    ServicesComponent,
    ListserviceComponent,
    HomeComponent,

    MembersComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    DataTablesModule,
    NgxPaginationModule
  ],
  providers: [
    AuthService,

    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
