import { Component, OnInit } from "@angular/core";
import { MyserviceService } from "../myservice.service";
import { Service } from "../service";
@Component({
  selector: "app-listservice",
  templateUrl: "./listservice.component.html",
  styleUrls: ["./listservice.component.css"]
})
export class ListserviceComponent implements OnInit {
  services: Service[];
  result: any;
  constructor(private _myservice: MyserviceService) {}

  ngOnInit() {
    this.getAllServices();
  }
  getAllServices() {
    this._myservice.getAllServices().subscribe(
      res => {
        this.services = res;
        console.log(this.services);
      },
      err => (this.result = "No Services Found..!")
    );
  }
}
