import { Component, OnInit } from "@angular/core";
import { AuthService } from "../auth.service";
import { Router } from "@angular/router";
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  loginUserData = {};
  result: any;
  isVisible = "hidden";
  constructor(private _auth: AuthService, private _router: Router) {}

  ngOnInit() {}

  loginUser() {
    this.showLoader();
    this._auth.loginUser(this.loginUserData).subscribe(
      res => {
        console.log(res);
        console.log(res.email);

        localStorage.setItem("token", res.token);
        localStorage.setItem("email", res.email);
        localStorage.setItem("usertype", res.usertype);
        this._router.navigate(["/home"]);
      },
      err => {
        console.log(err);
        this.result = "Invalid Email/Password..!";
        this.hideLoader();
      },
      () => this.hideLoader()
    );
  }

  showLoader() {
    this.isVisible = "visible";
  }
  hideLoader() {
    this.isVisible = "hidden";
  }
}
