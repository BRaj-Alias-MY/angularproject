import { Component, OnInit } from "@angular/core";
import { MyserviceService } from "../myservice.service";
@Component({
  selector: "app-members",
  templateUrl: "./members.component.html",
  styleUrls: ["./members.component.css"]
})
export class MembersComponent implements OnInit {
  members = [];
  result: any;
  usertype: any;
  isVisible = "hidden";
  constructor(private _myservice: MyserviceService) {}

  ngOnInit() {
    this.getMembers();
  }
  getMembers() {
    this.showLoader();
    this._myservice.getAllMembers().subscribe(
      res => {
        this.members = res;
      },
      err => (this.result = "No Members Found!"),
      () => this.hideLoader()
    );
  }
  showLoader() {
    this.isVisible = "visible";
  }
  hideLoader() {
    this.isVisible = "hidden";
  }
}
