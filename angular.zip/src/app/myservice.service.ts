import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Service } from "./service";

import { Observable } from "rxjs";
import { map } from "rxjs/operators";

@Injectable({
  providedIn: "root"
})
export class MyserviceService {
  private _addserviceUrl = "http://localhost:3000/api/services";
  private _getserviceUrl = "http://localhost:3000/api/show/";
  private _updateServiceUrl = "http://localhost:3000/api/updateservice/";
  private _deleteServiceUrl = "http://localhost:3000/api/deleteservice/";
  private _getAllServiceUrl = "http://localhost:3000/api/showall/";
  private _getAllMembers = "http://localhost:3000/api/showmembers/";
  private _checkEmail = "http://localhost:3000/api/checkemail/";
  constructor(private http: HttpClient) {}

  addService(serviceData) {
    return this.http.post<Service>(this._addserviceUrl, serviceData);
  }
  updateService(_id, serviceData) {
    return this.http.put<Service>(this._updateServiceUrl + _id, serviceData);
  }
  getServices(email: string): Observable<Service[]> {
    return this.http.get<Service[]>(this._getserviceUrl + email).pipe(
      map(response => {
        console.log(response);
        return response;
      })
    );
  }

  getAllServices(): Observable<Service[]> {
    return this.http.get<Service[]>(this._getAllServiceUrl).pipe(
      map(response => {
        console.log(response);
        return response;
      })
    );
  }

  deleteService(_id) {
    return this.http.delete(this._deleteServiceUrl + _id).pipe(
      map(response => {
        console.log(response);
        return response;
      })
    );
  }

  getAllMembers(): Observable<any[]> {
    return this.http.get<any[]>(this._getAllMembers).pipe(
      map(response => {
        console.log(response);
        return response;
      })
    );
  }

  checkEmail(email: string): Observable<Service> {
    return this.http.get<Service>(this._checkEmail + email).pipe(
      map(response => {
        console.log(response);
        return response;
      })
    );
  }
}
