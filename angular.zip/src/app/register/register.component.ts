import { Component, OnInit } from "@angular/core";
import { AuthService } from "../auth.service";
import { MyserviceService } from "../myservice.service";
import { Router } from "@angular/router";
import { Route } from "../../../node_modules/@angular/compiler/src/core";
@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  registerUserData = {};
  result: any;
  emailexists: any;
  emailstatus: any;
  isVisible = "hidden";
  constructor(
    private _auth: AuthService,
    private _router: Router,
    private _myservice: MyserviceService
  ) {}

  ngOnInit() {}
  checkEmail(email) {
    console.log(email);
    this._myservice.checkEmail(email).subscribe(
      res => {
        this.emailexists = res;
        if (this.emailexists == "exists") {
          this.emailexists = "Email Already Exists..!";
          this.emailstatus = true;
        } else {
          this.emailexists = "";
          this.emailstatus = false;
        }
      },
      err => console.log(err)
    );
  }
  registerUser() {
    this.showLoader();
    //console.log(this.registerUserData);
    this._auth.registerUser(this.registerUserData).subscribe(
      res => {
        console.log(res);
        localStorage.setItem("token", res.token);
        this.result = "Registration Successful.";
        // this._router.navigate(["/events"]);
      },
      err => {
        console.log(err);
        this.hideLoader();
      },
      () => this.hideLoader()
    );
  }
  showLoader() {
    this.isVisible = "visible";
  }
  hideLoader() {
    this.isVisible = "hidden";
  }
}
