export class Service {
  _id: string;
  title: string;
  email: string;
  description: string;
}
