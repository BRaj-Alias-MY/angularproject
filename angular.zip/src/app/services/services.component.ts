import { Component, OnInit } from "@angular/core";
import { MyserviceService } from "../myservice.service";
import { Service } from "../service";

@Component({
  selector: "app-services",
  templateUrl: "./services.component.html",
  styleUrls: ["./services.component.css"]
})
export class ServicesComponent implements OnInit {
  /*primary data members of the component */
  service: Service;
  title = "";
  _id = null;
  email = localStorage.getItem("email");
  description = "";
  result: any = "";
  services: Service[];
  buttonText = "Add Service";
  isVisible = "hidden";

  constructor(private _myservice: MyserviceService) {
    this.service = new Service();
  }

  ngOnInit() {
    this.email = localStorage.getItem("email");
    this.showServices();
  }
  /* to show list of services based on email of the service provider */
  showServices() {
    this.showLoader();
    this._myservice.getServices(this.email).subscribe(
      resp => {
        this.services = resp;
      },
      err => console.log(err),
      () => this.hideLoader()
    );
  }
  /*  Add and Update Service based on Button Text  */
  serviceAddUpdate() {
    this.showLoader();
    this.service.title = this.title;
    this.service.email = this.email;
    this.service.description = this.description;
    //add service if button text is Add Service
    if (this.buttonText === "Add Service") {
      console.log("test");
      this._myservice
        .addService(this.service)

        .subscribe(
          res => console.log(res),
          err => console.log(err),
          () => {
            this.showServices();
            this.clearText();
            this.hideLoader();
          }
        );
    }
    /*end of add service */
    /* update service if button text is Udpate Service */
    if (this.buttonText === "Update Service") {
      this.showLoader();
      this.buttonText = "Add Service";
      this.service._id = this._id;
      // console.log(this.service._id);
      this._myservice.updateService(this.service._id, this.service).subscribe(
        res => console.log(res),
        err => console.log(err),
        () => {
          this.showServices();
          this.service._id = null;
          this.clearText();
          this.hideLoader();
        }
      );
    }
    /*  end of update service  */
  }
  /*clear textbox values after insert and update */
  clearText() {
    this.title = null;
    this.description = null;
  }
  /* populate data on edito butotn click */
  editdata(id, title, description) {
    this._id = id;
    this.buttonText = "Update Service";
    this.title = title;
    this.description = description;
  }
  deleteService(_id) {
    this.showLoader();
    this._myservice.deleteService(_id).subscribe(
      res => console.log(res),
      err => {
        console.log(err);
        this.hideLoader();
      },
      () => {
        this.showServices();
        this.hideLoader();
      }
    );
    this.showServices();
  }
  showLoader() {
    this.isVisible = "visible";
  }
  hideLoader() {
    this.isVisible = "hidden";
  }
}
